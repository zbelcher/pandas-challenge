# pandas-challenge

I worked with classmates Paola, Astrid, and Grace who helped me troubleshoot some of my errors.

I also utilized ChatGPT to pull a few lines of code I was unable to figure out on my own.